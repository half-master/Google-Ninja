// Copyright 2011 Google Inc. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "graphviz.h"

#include <stdio.h>
#include <algorithm>

#include "dyndep.h"
#include "graph.h"

// add
#include <map>
#include <string>
#include <unordered_map>
#include <vector>

DotBuilder *db = new DotBuilder(); // global
ValueEdge *DotBuilder::buildValueEdge(char *style) {
  ValueEdge *ve = new ValueEdge();
  ve->style_ = style;
  return ve;
}
TreeNode *DotBuilder::buildTreeNode(string name) {
  TreeNode *temp = new TreeNode(name);
  return temp;
}

bool DotBuilder::modifydot() {
  int temp = 0;
  for (int i = 0; i < db->treenodes_.size(); i++) {
    if (db->treenodes_[i]->valuedot_.label_.c_str()[0] == 'g' &&
        db->treenodes_[i]->valuedot_.label_.c_str()[1] == '.') {
      // Warning("123");
      db->treenodes_[i]->isignore_ = true;
      temp++;
      for (auto iter = db->treenodes_[i]->dict_child_.begin();
           iter != db->treenodes_[i]->dict_child_.end(); ++iter) {
        db->addr_hashmap_[iter->first]->dict_father_ = db->treenodes_[i]->dict_father_;
      }
    }
  }
  db->num_release_ = db->num_previous_ - temp;
  return true;
}

/// ninja -f build.ninja -t graph {target} -outfile {svg,dot} -ignore
bool DotBuilder::writedot() {
  if (1 == flag_ignore) {
    Warning("Modify !!!!!!!!!!!!!!!!!!!!!!!!!");
    modifydot();
  }
  Warning("previous %d", db->num_previous_);
  Warning("release %d", db->num_release_);

  Warning("%d", flag_ignore);
  FILE *fps = fopen("./xxx.dot", "w+");

  // head
  fprintf(fps, "digraph ninja {\n");
  fprintf(fps, "rankdir=\"LR\"\n");
  fprintf(fps, "node [fontsize=10, shape=box, height=0.25]\n");
  fprintf(fps, "edge [fontsize=10]\n");
  db->treenodes_[0]->valuedot_.shape = "box3d";
  db->treenodes_[0]->valuedot_.color = "red";

  for (int i = 0; i < treenodes_.size(); i++) {
    if (db->treenodes_[i]->isignore_ == false) {
      fprintf(fps,
              string(treenodes_[i]->name_ + "[label=\"" +
              treenodes_[i]->valuedot_.label_ + "\", color=\"" +
              treenodes_[i]->valuedot_.color + "\", shape=\"" +
              treenodes_[i]->valuedot_.shape + "\"]").c_str());
      fprintf(fps, "\n");
      for (auto iter = treenodes_[i]->dict_father_.begin();
        iter != treenodes_[i]->dict_father_.end(); iter++) {
          fprintf(fps,
                  string(treenodes_[i]->name_ + " -> " + iter->first +
                  "[arrowhead=\"" + iter->second.arrowhead_ +
                  "\", style= \"" + iter->second.style_ +
                  "\", label=\"" + iter->second.label_ + "\"]").c_str());
          fprintf(fps, "\n");
      }
    }
  }

  // tail
  fprintf(fps, "}\n");
  fclose(fps);
  return true;
}

void GraphViz::AddTarget(Node* node) {
  if (nullptr == db) {
    Warning("DotBuilder is empty !");
    db = new DotBuilder();
  }

  if (visited_nodes_.find(node) != visited_nodes_.end())
    return;
  db->count_++;
  string pathstr = node->path();
  replace(pathstr.begin(), pathstr.end(), '\\', '/');
  char name[1024] = "";
  sprintf(name, "\"%p\"", node);

  if (db->addr_hashmap_.find(name) == db->addr_hashmap_.end()) {
    TreeNode *tn = db->buildTreeNode(name);
    db->treenodes_.push_back(tn);
    db->addr_hashmap_.emplace(name, tn);
  }
  db->addr_hashmap_[name]->valuedot_.label_ = pathstr;

  printf("\"%p\" [label=\"%s\"]\n", node, pathstr.c_str());

  visited_nodes_.insert(node);
  Edge* edge = node->in_edge();

  if (!edge) {
    // Leaf node.
    // Draw as a rect?
    return;
  }

  if (visited_edges_.find(edge) != visited_edges_.end())
    return;
  visited_edges_.insert(edge);

  if (edge->dyndep_ && edge->dyndep_->dyndep_pending()) {
    std::string err;
    if (!dyndep_loader_.LoadDyndeps(edge->dyndep_, &err)) {
      Warning("%s\n", err.c_str());
    }
  }

  if (edge->inputs_.size() == 1 && edge->outputs_.size() == 1) {
    char namefather[1024] = "";
    sprintf(namefather, "\"%p\"", edge->outputs_[0]);
    char nameself[1024] = "";
    sprintf(nameself, "\"%p\"", edge->inputs_[0]);

    ValueEdge* ve = db->buildValueEdge("");

    if (db->addr_hashmap_.find(nameself) == db->addr_hashmap_.end()) {
      TreeNode* tn = db->buildTreeNode(nameself);
      db->treenodes_.push_back(tn);
      db->addr_hashmap_.emplace(nameself, tn);
    }
    if (db->addr_hashmap_.find(nameself) != db->addr_hashmap_.end()) {
      db->addr_hashmap_[string(nameself).c_str()]->dict_father_.emplace(
          namefather, *db->buildValueEdge(""));
        db->addr_hashmap_[nameself]->dict_father_[namefather].label_ =
                edge->rule_->name();
    }

    if (db->addr_hashmap_.find(namefather) == db->addr_hashmap_.end()) {
      TreeNode *tn = db->buildTreeNode(namefather);
      db->treenodes_.push_back(tn);
      db->addr_hashmap_.emplace(namefather, tn);
    }
    if (db->addr_hashmap_.find(namefather) != db->addr_hashmap_.end()) {
      db->addr_hashmap_[string(namefather).c_str()]->dict_child_.emplace(nameself, *ve);
    }

    printf("\"%p\" -> \"%p\" [label=\" %s\"]\n", edge->inputs_[0],
           edge->outputs_[0], edge->rule_->name().c_str());
    } else {
      char nameself[1024] = "";
      sprintf(nameself, "\"%p\"", edge);
      // find itself
      if (db->addr_hashmap_.find(nameself) == db->addr_hashmap_.end()) {
        TreeNode *tn = db->buildTreeNode(nameself);
        db->treenodes_.push_back(tn);
        db->addr_hashmap_.emplace(nameself, tn);
      }
      if (db->addr_hashmap_.find(nameself) != db->addr_hashmap_.end()) {
        char label[1024] = "";
        sprintf(label, "\"%s\"", edge->rule_->name().c_str());

        db->addr_hashmap_[nameself]->valuedot_.label_ = edge->rule_->name();

        db->addr_hashmap_[nameself]->valuedot_.shape = "ellipse";
      }
      printf("\"%p\" [label=\"%s\", shape=ellipse]\n", edge,
             edge->rule_->name().c_str());

      for (vector<Node *>::iterator out = edge->outputs_.begin();
        out != edge->outputs_.end(); ++out) {
        printf("\"%p\" -> \"%p\"\n", edge, *out);

        char nameself[1024] = "";
        char namefather[1024] = "";
        sprintf(nameself, "\"%p\"", edge);
        sprintf(namefather, "\"%p\"", *out);

        if (db->addr_hashmap_.find(nameself) == db->addr_hashmap_.end()) {
          TreeNode *tn = db->buildTreeNode(nameself);

          db->treenodes_.push_back(tn);
          db->addr_hashmap_.emplace(nameself, tn);
        }
        if (db->addr_hashmap_.find(nameself) != db->addr_hashmap_.end()) {
          db->addr_hashmap_[string(nameself).c_str()]
            ->dict_father_.emplace(namefather, *db->buildValueEdge(""));
        }

        if (db->addr_hashmap_.find(namefather) == db->addr_hashmap_.end()) {
          TreeNode *tn = db->buildTreeNode(namefather);

          db->treenodes_.push_back(tn);
          db->addr_hashmap_.emplace(namefather, tn);
        }

        if (db->addr_hashmap_.find(namefather) != db->addr_hashmap_.end()) {
          db->addr_hashmap_[string(namefather).c_str()]
            ->dict_child_.emplace(nameself, *db->buildValueEdge(""));
        }
    }
    for (vector<Node*>::iterator in = edge->inputs_.begin();
         in != edge->inputs_.end(); ++in) {
      const char* order_only = "";
      if (edge->is_order_only(in - edge->inputs_.begin()))
        order_only = " style=dotted";
      char nameself[1024] = "";
      char namefather[1024] = "";
      sprintf(nameself, "\"%p\"", (*in));
      sprintf(namefather, "\"%p\"", edge);

      if (db->addr_hashmap_.find(nameself) == db->addr_hashmap_.end()) {
        TreeNode *tn = db->buildTreeNode(nameself);

        db->treenodes_.push_back(tn);
        db->addr_hashmap_.emplace(nameself, tn);
      }
      if (db->addr_hashmap_.find(nameself) != db->addr_hashmap_.end()) {

        db->addr_hashmap_[string(nameself).c_str()]
          ->dict_father_.emplace(namefather, *db->buildValueEdge(""));

        db->addr_hashmap_[string(nameself).c_str()]
          ->dict_father_[namefather]
          .style_ = order_only;
        db->addr_hashmap_[nameself]
          ->dict_father_[namefather]
          .arrowhead_ = "none";
      }

      if (db->addr_hashmap_.find(namefather) == db->addr_hashmap_.end()) {
        TreeNode *tn = db->buildTreeNode(namefather);

        db->treenodes_.push_back(tn);
        db->addr_hashmap_.emplace(namefather, tn);
      }
      if (db->addr_hashmap_.find(namefather) != db->addr_hashmap_.end()) {
        db->addr_hashmap_[string(namefather).c_str()]
          ->dict_child_.emplace(nameself, *db->buildValueEdge(""));
      }

      printf("\"%p\" -> \"%p\" [arrowhead=none%s]\n", (*in), edge, order_only);
    }
  }
  for (vector<Node*>::iterator in = edge->inputs_.begin();
       in != edge->inputs_.end(); ++in) {
    AddTarget(*in);
  }
  db->num_previous_ = db->treenodes_.size();
}

void GraphViz::Start() {
  printf("digraph ninja {\n");
  printf("rankdir=\"LR\"\n");
  printf("node [fontsize=10, shape=box, height=0.25]\n");
  printf("edge [fontsize=10]\n");
}

void GraphViz::Finish() {
  printf("}\n");
}
